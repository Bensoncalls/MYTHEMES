<?php

class demoData
{
    public function initData()
    {
        $return = true;
        $languages = Language::getLanguages(true);
        $id_shop = Context::getContext()->shop->id;
        $id_hook_nav = (int)Hook::getIdByName('displayNav');
        $id_hook_top = (int)Hook::getIdByName('displayTopColumn');
        $id_hook_home = (int)Hook::getIdByName('displayHome');
        $id_hook_bottom = (int)Hook::getIdByName('displayFullbottom');
        
        $queries = [
            'INSERT INTO `'._DB_PREFIX_.'pos_staticblock` (`id_pos_staticblock`, `id_hook`, `position`, `name`,`active`) VALUES
                (1, '.$id_hook_nav.', 1, "Staticblock Home", 1),
                (2, '.$id_hook_top.', 2, "Staticblock1 Home4", 1),
                (3, '.$id_hook_home.', 3, "Staticblock2 Home4", 1),
                (4, '.$id_hook_bottom.', 4, "Staticblock3 Home4", 1)'

            
        ];

        foreach (Language::getLanguages(true, Context::getContext()->shop->id) as $lang) {
            $queries[] = 'INSERT INTO `'._DB_PREFIX_.'pos_staticblock_lang` (`id_pos_staticblock`, `id_lang`, `content`) VALUES
                (1, '.(int)$lang['id_lang'].', \'<div id="_desktop_static">
					<div class="static-nav">
					<div class="email"><a href="#">Support@posthemes.com</a></div>
					<div class="map"><a href="contact-us">Store Locator</a></div>
					</div>
					</div>\'),
                (2, '.(int)$lang['id_lang'].', \'<div class="home-banner">
					<div class="container">
					<div class="box-iner">
					<div class="row">
					<div class="col-xs-12 col-sm-6 col-md-3 col box1">
					<div class="box">
					<div class="img-icon"><img src="/pos_jena/img/cms/icon1_home3.png" alt="" class="img-responsive" /></div>
					<div class="text">
					<h2>Free Shipping</h2>
					<p>On all orders over $75.00</p>
					</div>
					</div>
					</div>
					<div class="col-xs-12 col-sm-6 col-md-3 col box2">
					<div class="box">
					<div class="img-icon"><img src="/pos_jena/img/cms/icon2_home3.png" alt="" class="img-responsive" /></div>
					<div class="text">
					<h2>Free Free Returns</h2>
					<p>Returns are free within 9 days</p>
					</div>
					</div>
					</div>
					<div class="col-xs-12 col-sm-6 col-md-3 col box3">
					<div class="box">
					<div class="img-icon"><img src="/pos_jena/img/cms/icon3_home3.png" alt="" class="img-responsive" /></div>
					<div class="text">
					<h2>100% Payment Secure</h2>
					<p>Your payment are safe with us.</p>
					</div>
					</div>
					</div>
					<div class="col-xs-12 col-sm-6 col-md-3 col box4">
					<div class="box">
					<div class="img-icon"><img src="/pos_jena/img/cms/icon4_home3.png" alt="" class="img-responsive" /></div>
					<div class="text">
					<h2>Support 24/7</h2>
					<p>Contact us 24 hours a day</p>
					</div>
					</div>
					</div>
					</div>
					</div>
					</div>
					</div>\'),
				(3, '.(int)$lang['id_lang'].', \'<div class="static3_home2">
					<div class="pos_title"><span>Awesome Shop</span>
					<h2>Jena Collection</h2>
					</div>
					<div class="row">
					<div class="col-xs-12 col-sm-12 col-md-6 col box1">
					<div class="banner-box"><a href="#"><img src="/pos_jena/img/cms/img4_home2.jpg" alt="" class="img-responsive" /></a></div>
					</div>
					<div class="col-xs-12 col-sm-12 col-md-6 col box2">
					<div class="top">
					<div class="bos1 col-xs-12 col-sm-6 col-md-6 col">
					<div class="banner-box"><a href="#"><img src="/pos_jena/img/cms/img5_home2.jpg" alt="" class="img-responsive" /></a></div>
					</div>
					<div class="bos2 col-xs-12 col-sm-6 col-md-6 col">
					<div class="banner-box"><a href="#"><img src="/pos_jena/img/cms/img6_home2.jpg" alt="" class="img-responsive" /></a></div>
					</div>
					</div>
					<div class="bottom">
					<div class="bos1 col-xs-12 col-sm-6 col-md-6 col">
					<div class="banner-box"><a href="#"><img src="/pos_jena/img/cms/img7_home2.jpg" alt="" class="img-responsive" /></a></div>
					</div>
					<div class="bos2 col-xs-12 col-sm-6 col-md-6 col">
					<div class="banner-box"><a href="#"><img src="/pos_jena/img/cms/img8_home2.jpg" alt="" class="img-responsive" /></a></div>
					</div>
					</div>
					</div>
					</div>
					</div>\'),
				(4, '.(int)$lang['id_lang'].', \'<div class="static2">
					<div class="container">
					<h2>100% Organic.</h2>
					<h3>Natural <span>Fresh Juice</span></h3>
					<p>Made of 100% Valencia oranges to hold a perfect balance of sweet and tart flavor. This juice is made most enjoyable by the absence of the pulb!</p>
					<a class="shop" href="#">Discover Now</a></div>
					</div>\')'
                
            ;
        }

        $queries[] = 'INSERT INTO `'._DB_PREFIX_.'pos_staticblock_shop` (`id_pos_staticblock`, `id_shop`) VALUES
                (1, 1),
                (2, 1),
                (3, 1),
                (4, 1)'; 

        foreach ($queries as $query) {
            $return &= Db::getInstance()->execute($query);
        }

        return $return;
    }
}
?>